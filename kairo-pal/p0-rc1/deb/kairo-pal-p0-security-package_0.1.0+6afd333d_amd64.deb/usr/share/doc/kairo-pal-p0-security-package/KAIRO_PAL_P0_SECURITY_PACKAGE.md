# KAIRO+PAL P0 Security Package

## Scope

This release packages the current `kairo-sec` gates and PAL boundary connectors as a defensive layer for existing Linux and Windows systems.

This is not a TUFF-OS lower-OS integration release.

## Included Gates

- Dirty Frag
- PamDOORa
- Rancher Fleet CVE-2026-41050
- Encoded Prompt Wallet abuse
- Starlette BadHost / MCP boundary
- Developer remote bootstrap integrity / remote execution pivot

## PAL Boundary Targets

- WinSec intake
- Local AI runtime connector
- Developer remote execution boundary
- Browser sync vault trust boundary

## PAL / KAIRO Boundary Rule

### PAL

- Windows / AD / EventLog / WinRM / NTFS / BitLocker / updater の Win 固有意味判定
- `WinSecResponsePolicy`
- `EventLogRecord` mapping
- `EventLogWindow` aggregation
- Windows Security EventLog one-shot reader
- XML / 欠損 / UnknownIdentity 安全化

### KAIRO

- VS Code Remote-SSH / MCP / browser sync vault / developer endpoint to cloud pivot の総合境界判定
- `kairo-sec` gates
- `KAIRO-net` verdict execution
- safe release profiles
- `.deb` / Windows installer packaging

### Connection

- PAL finding must be converted to a stable `response_policy` record.
- KAIRO must consume PAL `response_policy` as an input verdict source, not reinterpret raw Windows semantics.
- `DeveloperToolRemoteExecutionGate` must not duplicate PAL WinSec semantics.
- Windows-specific findings caused after a remote/developer pivot must be emitted by PAL and then consumed by KAIRO.

## Default Mode

- Observe for normal telemetry.
- Quarantine for suspicious trust-boundary execution.
- Fail closed for critical boundary violations.

## Safety Constraints

- No kernel driver installation.
- No default firewall mutation.
- No default XDP/TC attachment.
- No exploit reproduction.
- No live external scanner behavior.
- No automatic model loading.
- No lower-OS integration claims.

## Packaging Notes

- Linux `.deb` and Windows installer scaffolding are provided for release packaging.
- If a suitable runtime binary is absent, the packaging scripts fail clearly instead of inventing runtime behavior.
- The package is intended to be a defensive layer over existing systems, not a replacement for vendor products or lower-OS integration.
