# Browser Sync Vault Trust Boundary

Browser sync vaults are convenience stores, not the root of trust.

## Boundary Statement

- Chrome sync, Google Password Manager, Proton, iCloud Keychain, and Edge sync traffic are not modified by KAIRO or PAL.
- KAIRO and PAL must not depend on browser sync vaults for privileged credentials.
- Privileged credentials, TUFF keys, SSH private keys, signing keys, CI/CD tokens, and cloud admin tokens must remain outside browser sync vaults.

## Risk Class

This boundary covers VaultJacking-style design risk where synced browser vault content becomes a pivot point for credential exposure or device-join abuse.

## Future Gate Candidate

- `CredentialVaultSyncGate`

This future gate would treat vault sync as a convenience channel, not a root of trust, and would refuse to elevate browser-synced material into privileged TUFF trust.
